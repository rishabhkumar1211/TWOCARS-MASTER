link: https://rishabhkumar1211.github.io/TwoCars/

Rules:
  1. use left arrow key to control left car
  2. use right arrow key to control right
  3. collect all circlular obstacles 
  4. beaware of all rectangular objects
  5.you have two option either you play easy level or hard
 
ENJOY THE GAME ....GOOD LUCK :)
  
